class QueenChessBoard:
    def __init__(self, size):
        self.size = size
        self.columns = []
    def is_safe(self, row, column):
        for prev_row, prev_col in enumerate(self.columns):
            if prev_col == column or abs(prev_col - column) == abs(prev_row - row):
                return False
        return True
    def solve(self, row=0):
        if row == self.size:
            return [self.columns[:]]
        solutions = []
        for col in range(self.size):
            if self.is_safe(row, col):
                self.columns.append(col)
                solutions.extend(self.solve(row + 1))
                self.columns.pop()
        return solutions
    def display_solution(self, solution):
        for row_idx in solution:
            row_str = ''.join('Q' if col == row_idx else ' . ' for col in range(self.size))
            print(row_str)
            print()
def solve_queen(size):
    board = QueenChessBoard(size)
    solutions = board.solve()
    print(f'Number of solutions: {len(solutions)}')
    for solution in solutions:
        board.display_solution(solution)
n = int(input('Enter n: '))
solve_queen(n)
print("Praveen Pal 24")